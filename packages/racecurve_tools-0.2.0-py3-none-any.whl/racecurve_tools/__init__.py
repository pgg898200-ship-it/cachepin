"""RaceCurve paired-trace analysis tools."""
